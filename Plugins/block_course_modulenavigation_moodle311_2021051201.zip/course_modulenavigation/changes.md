Version Information
===================
Version 1 (2016.04.26)
  1. First release

Version 3.1 (2016.06.09)
  1. Add Travis to check code 
  2. Add Gruntfile copyright
  3. Fix bug where activities and resources having a visibility set to "hidden" are shown in the menu (thank to Mathias)
  4. Check for Moodle 3.1

Version 3.2 (2016.06.23)
  1. Define $myactivityid earlier
  2. Add descriptions to templates
  3. Fix a bug with the option "show the current section only" where link of title section doesn't work

Version 3.3 (2016.08.01)
  1. Add links on the sections titles. Now each section title point to section page
  2. Add an arrow after sections titles to open menu content.

Version 3.4 (2016.10.07)
  1. Add option between downwards arrow and click on title
  2. Show labels in the menu
  3. Add option to show all tabs open

  Version 3.5 (2016.11.22)
  1. Compatibility with Moodle 3.2
  2. Add option to show only course titles

 Version 3.6 (2017.06.20)

  1. Check and update to Moodle version 3.3
  2. Update plugin for MDL-57769 - Course formats: Attribute 'numsections' was removed from topics and weeks, other course formats may want to implement similar changes

Version 4.0 (2018.11.14)

 1. Moodle 3.6 compatible
 2. Fix some minor issues
 
 Version 4.1 (2019.02.13)

 1. Fix bug with a critical issue
 2. Review indent and update code doc